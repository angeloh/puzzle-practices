package com.mars;
/**
 * @author Angelo K. Huang
 * command interface
 */
public interface Command {
	public void execute();	
}