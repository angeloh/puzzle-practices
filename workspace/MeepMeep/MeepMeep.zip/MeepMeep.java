public class MeepMeep {
	public static void main(String [] args) {
		if (args.length == 0) {
			System.out.println("Please provide a input file!!");
			return;
		}		
		System.out.println("Meep meep!");
	}
}